# read more less toggle

A Pen created on CodePen.io. Original URL: [https://codepen.io/_kashmira/pen/YpVjrM](https://codepen.io/_kashmira/pen/YpVjrM).

